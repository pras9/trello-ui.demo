// <reference path="counter.js">
"use strict";
 
describe("Counter tests", function () {
 
    it("Add gives the correct result", function () {
        // Arrange
        var num1 = 1;
        var num2 = 3;
        var expected = 4;
 
        // Act
        var result = counter.add(num1, num2);
 
        // Assert
        expect(result).toBe(expected);
    });
 
	it("Subtraction gives the correct result", function () {
        // Arrange
        var num1 = 1;
        var num2 = 3;
        var expected = -2;
 
        // Act
        var result = counter.subtract(num1, num2);
 
        // Assert
        expect(result).toBe(expected);
    });
	it("Difference gives zero when both numbers are the same", function () {
        for (var i = 0; i <= 100; i++) {
            // Arrange
            var expected = 0;
 
            // Act
            var result = counter.difference(i, i);
 
            // Assert
            expect(result).toBe(expected);
        }
    });
	
	
    
 
});
describe("Ajax Tests", function() {
    var configuration = {
        url : "ProductData.json",
        remainingCallTime : 30000
    };

    it("should make an Ajax request to the correct URL", function() {
        spyOn($, "ajax");
        sendRequest(undefined, configuration);
		
        expect($.ajax.mostRecentCall.args[0]["url"]).toEqual(configuration.url);
    });
	
	it("should receive a successful response", function() {
        spyOn($, "ajax").andCallFake(function(e) {
            e.success({});
        });

        // Creatring some mock object for test
        var callbacks = {
            checkForInformation : jasmine.createSpy(),
            displayErrorMessage : jasmine.createSpy(),
        };

        sendRequest(callbacks, configuration);
        expect(callbacks.checkForInformation).toHaveBeenCalled();
        //Verifies this was called
        expect(callbacks.displayErrorMessage).not.toHaveBeenCalled();
        //Verifies this was NOT called
    });
	
	it("should receive a error response", function() {
        spyOn($, "ajax").andCallFake(function(e) {
            e.error({});
        });

        // Creatring some mock object for test
        var callbacks = {
            displayErrorMessage : jasmine.createSpy()
        };

        sendRequest(callbacks, configuration);
        expect(callbacks.displayErrorMessage).toHaveBeenCalled();
        
    });
	
	it("should receive a remining call time", function() {
        spyOn($, "ajax");
		 var configuration = {
        	url : "ProductData.json",
        	remainingCallTime : 30000
    	};
        
        sendRequest(undefined, configuration);
//		console.log($.ajax.mostRecentCall.args[0].timeout);
        expect($.ajax.mostRecentCall.args[0].timeout).toEqual(configuration.remainingCallTime);
        
    });
	

});
